# NETWORK-ADMINISTRATION
- All `7` network layers and secret `3` others.
